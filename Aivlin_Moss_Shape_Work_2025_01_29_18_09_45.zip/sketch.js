function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("lightblue");
  
 
  fill("tan")
 stroke(0,0)
  rect(0,320,400,80);
 
  fill ('darkorange')
  triangle(300,250,360,200,360,270)
          
  fill('orange')
  stroke(0,0)
  ellipse(240,240,160,120)

fill('white')
circle(200,230,30,30)
  
fill ('black')
circle(195,230,20,20)
 
fill ('darkorange')
triangle(270, 270, 230, 250, 290, 230)
 
fill ('deepskyblue')
circle (140, 200, 20, 20)
fill ('deepskyblue')
circle (100, 150, 30, 20);
  

}